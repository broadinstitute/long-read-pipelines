# Set our version:
__version__ = "1.2.0"

# Import our tesserae class for easy access and tell flake8 checks to ignore it:
from .tesserae import Tesserae  # noqa: F401
