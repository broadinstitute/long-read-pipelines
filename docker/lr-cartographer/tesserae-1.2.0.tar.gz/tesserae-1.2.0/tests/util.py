import pathlib

TEST_RESOURCES_FOLDER = pathlib.Path(__file__).resolve().parent / "resources"
EXPECTED_TEST_RESULTS = TEST_RESOURCES_FOLDER / "integration_test_expected_output.sam"
